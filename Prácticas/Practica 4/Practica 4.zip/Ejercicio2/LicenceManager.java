package gof3_ejer2;
public class LicenceManager {
	public static boolean checkIsFullVersion() {
		return false;
	}
}
