/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gof1_ejer2;

/**
 *
 * @author Alex
 */
public class Autor {
	
	private String nombre;
	
	public Autor(String nombre){
		
		this.nombre = nombre;
		
	}
	
	public String getNombre(){
		
		return this.nombre;
	}

}
