package gof1;

public class ZapadorAtreides implements Zapador {

	@Override
	public void mover(int x, int y) {
	}

	@Override
	public void ponerBomba() {
		System.out.println("Estoy poniendo una bomba al estilo atreides!!");
	}

}
