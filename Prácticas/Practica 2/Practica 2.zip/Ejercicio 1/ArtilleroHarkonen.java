package gof1;

public class ArtilleroHarkonen implements Artillero {

	@Override
	public void mover(int x, int y) {		
	}

	@Override
	public void disparar() {
		System.out.println("Estoy disparando con punteria harkonen!!");


	}

}
