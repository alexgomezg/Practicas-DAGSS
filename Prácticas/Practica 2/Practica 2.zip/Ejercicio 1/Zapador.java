package gof1;

public interface Zapador extends Soldado{
	public void ponerBomba();
}
