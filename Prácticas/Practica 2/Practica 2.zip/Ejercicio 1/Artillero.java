package gof1;

public interface Artillero extends Soldado {
	public void disparar();
}
