package gof1;
public class ZapadorHarkonen implements Zapador {

	@Override
	public void mover(int x, int y) {		
	}

	@Override
	public void ponerBomba() {
		System.out.println("Estoy poniendo una bomba al estilo harkonen!!");
	}

}
