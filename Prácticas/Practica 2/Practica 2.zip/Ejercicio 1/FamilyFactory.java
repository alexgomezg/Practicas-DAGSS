package gof1;

public interface FamilyFactory {
	public Artillero addArtillero();
	public Zapador addZapador();

}
