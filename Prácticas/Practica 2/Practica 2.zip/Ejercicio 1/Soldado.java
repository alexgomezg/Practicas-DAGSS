package gof1;

public interface Soldado {
	public void mover(int x, int y);
}
